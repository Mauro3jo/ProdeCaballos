<template>
  <router-view />
</template>

<script setup>
// Ya no necesitas nada más acá, Vue Router maneja las vistas y los ids.
</script>
