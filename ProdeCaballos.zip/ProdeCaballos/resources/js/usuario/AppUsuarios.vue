<template>
  <div>
    <NavbarUsuarios />
    <router-view />
  </div>
</template>

<script setup>
import NavbarUsuarios from './NavbarUsuarios.vue'
</script>
