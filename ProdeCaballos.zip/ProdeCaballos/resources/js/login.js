import { createApp } from 'vue'
import Login from './Login/Login.vue'

createApp(Login).mount('#app')
