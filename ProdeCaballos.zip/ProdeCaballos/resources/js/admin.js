import { createApp } from 'vue'
import Home from './Admin/Home.vue'

createApp(Home).mount('#app')
