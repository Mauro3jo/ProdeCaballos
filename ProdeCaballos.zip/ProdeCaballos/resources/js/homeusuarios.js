import { createApp } from 'vue';
import AppUsuarios from './usuario/AppUsuarios.vue';
createApp(AppUsuarios).mount('#app');
