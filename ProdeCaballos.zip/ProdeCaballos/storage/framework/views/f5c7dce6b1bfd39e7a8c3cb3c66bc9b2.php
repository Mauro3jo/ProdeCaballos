<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title>Login</title>
  <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/login.js']); ?>
</head>
<body>
  <div id="app"></div>
</body>
</html>
<?php /**PATH C:\Users\mauro_j2pjkpe\OneDrive\Documentos\GitHub\ProdeCaballos\ProdeCaballos\resources\views/auth/login.blade.php ENDPATH**/ ?>